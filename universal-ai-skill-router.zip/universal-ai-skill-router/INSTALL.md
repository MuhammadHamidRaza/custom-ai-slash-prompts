# Installation — Universal AI Skill Router

Package: `universal-ai-skill-router.zip` (the ZIP contains one top-level folder, `universal-ai-skill-router/`, with `SKILL.md` inside it).

## Claude.ai (web / desktop)
1. Open your account Settings and find the **Skills** area (under Capabilities / Customize; the exact label and location change between versions).
2. Choose to **upload a skill** and select `universal-ai-skill-router.zip`.
3. Make sure the skill is **toggled on**. Skills may require Code Execution / file creation to be enabled in the same settings area.
4. Start a new chat and run: `/universal-ai-skill-router teacher Teach me Docker from beginner level.`

Note: in Claude.ai, skills are activated by Claude matching your message to the skill description, not by a built-in slash menu. Starting your message with `/universal-ai-skill-router ...` (or a library shortcut such as `/teacher ...`) is what triggers it reliably.

## Claude Code
```bash
# personal (all projects)
mkdir -p ~/.claude/skills && unzip universal-ai-skill-router.zip -d ~/.claude/skills/
# or project-only
mkdir -p .claude/skills && unzip universal-ai-skill-router.zip -d .claude/skills/
```
Restart or reload the session. The skill is then available as `/universal-ai-skill-router`.

## Claude API / Agent SDK
Upload the folder through the Skills API (or place it in your agent's skills directory), then enable it for the container. See Anthropic's Skills documentation for the current request format.

## Verify the install (30 seconds)
1. `/universal-ai-skill-router help` → usage guide with 9 categories totalling 763 commands.
2. `/universal-ai-skill-router swot` → explains `/swot` and asks for a task (does not invent one).
3. `/universal-ai-skill-router zzzunknown hello` → says the command is not in the library and suggests nearest ones.
4. `/universal-ai-skill-router teacher + eli5 + analogy Explain how DNS works` → combined lesson.

## Optional: run the self-checks locally (needs Python 3)
```bash
cd universal-ai-skill-router
python3 scripts/verify.py          # README vs registry vs files; rewrites VERIFICATION-REPORT.md
python3 scripts/run_tests.py       # 3,860 parse-level tests
python3 scripts/lookup.py "/teacher + /stepbystep Teach me Git"
```

## Updating the library
Edit `source/README.original.md` only as the spec; to add a command, add its row to the matching category file under `references/commands/`, add it to `references/command-registry.json` and the index in `references/command-registry.md`, then run `scripts/verify.py` and `scripts/run_tests.py`. Do not give two commands the same meaning or the same name (README rule).

## Customizing
- A user-supplied definition in chat overrides a library definition for that session.
- To change a command permanently, edit its line in its category file and in `command-registry.json` (the verifier compares both).
